import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
  Picker,
  TextInput,
} from 'react-native';
import {firebase} from '../config/firebase'
import {
  BookingCalendar
} from 'react-native';
import RNPickerSelect from "react-native-picker-select";
  import Calendar from 'react-calendar';
import moment from 'moment';
    





function Reservations({ navigation }) {
 const [selectedValue, setSelectedValue] = useState('java');
 const [firstName, setFirstName] = useState("")
 const [lastName, setLastName] = useState("")
 const [email, setEmail] = useState("")
 const [address, setAddress] = useState("")
 const [city, setCity] = useState("")
const [checkIn, setCheckIn] = useState("")
const [checkOut, setCheckOut] = useState("")
const [children, setChildren] = useState("")
const [adult, setAdult] = useState("")


   
 const Navigation = () => {
  firebase.firestore().collection("Bookings").doc(firebase.auth().currentUser.uid).set({
    firstName,
    lastName,
    email,
    address,
    city,
    checkIn,
    checkOut,
    children,
    adult,


   
})
.then(() => {
    console.log("Document successfully written!");
})
.catch((error) => {
    console.error("Error writing document: ", error);
});
}
    

            

  return (
    <View>
      <Text
        style={{
          alignSelf: 'center',
          fontSize: 20,
          fontWeight: 'bold',
          marginTop: 20,
          color:'gray'
        }}>
        Reservations Details
      </Text>
  
      <View
        style={{ flexDirection: 'row', marginTop: 40, alignSelf: 'center' }}>
        <View style={{ marginLeft: -10, padding: 10 }}>
          <TextInput style={styles.input} placeholder="First Name"   onChangeText= {(name) => setFirstName(name)} />
        </View>
        <View>
          <TextInput style={styles.input2} placeholder="Last Name"  onChangeText= {(name) => setLastName(name)}/>
        </View>
      </View>
      <View style={{ flexDirection: 'row', alignSelf: 'center' }}>
        <View style={{ marginLeft: -10, padding: 10 }}>
          <TextInput style={styles.input} placeholder="E-mail"  onChangeText= {(name) => setEmail(name)}/>
        </View>
        <View>
          <TextInput style={styles.input2} placeholder="Address"  onChangeText= {(name) => setAddress(name)}/>
        </View>
        
      </View>
        <View style={{ flexDirection: 'row', alignSelf: 'center' }}>
        <View style={{ marginLeft: -10, padding: 10 }}>
          <TextInput style={styles.input} placeholder="checkIn"  onChangeText= {(name) => setCheckIn(name)}/>
        </View>
        <View >
          <TextInput style={styles.input2} placeholder="check-out"  onChangeText= {(name) => setCheckOut(name)}/>
        </View>
        </View>
        
      <View
        style={{ flexDirection: 'row', marginTop: 40, alignSelf: 'center' }}>
        
        <View style={{ marginLeft: -10, padding: 10,marginTop:-30 }}>
          <TextInput style={styles.input} placeholder="City"  onChangeText= {(name) => setCity(name)}/>
          </View>
          <View style={{marginTop:-30}}>
            <TextInput style={styles.input2} placeholder="Phone number" />
        </View>
      </View>
        <View style={styles.java}>
    <Text style={{ marginLeft: 1, fontWeight: 'relative', justifyContent: 'space-evenly'}}>Adults</Text>
    <RNPickerSelect
                 onValueChange={(value) => console.log(value)}
                 items={[
                  { label: "1", value: "1" },
                  { label: "2", value: "2" },
                  { label: "3", value: "3" },
                  { label: "more", value: "more" },
                 ]}
             />
                 <Text style={{ marginLeft: 3, fontWeight: 'relative', justifyContent: 'space-evenly'}}>Childen</Text>
               <RNPickerSelect style={{width:5}}
                 onValueChange={(value) => console.log(value)}
                 items={[
                     { label: "1", value: "1" },
                     { label: "2", value: "2" },
                     { label: "3", value: "3" },
                     { label: "more", value: "more" },
                 ]}
             />
    </View>
          <View > 
         
             <View style={styles.btn}>
              <TouchableOpacity onPress={Navigation}>
                <Text style={{color:'white',alignSelf:'center',marginTop:10,fontWeight:'bold'}}>Submit</Text>
              </TouchableOpacity>

              </View>
             </View>
              <View style={styles.button}>
              <TouchableOpacity   style={{marginTop: "15%"}}>
                <Text
                  style={{color:'white',alignSelf:'center',marginTop:-17,fontWeight:'bold'}}
                  onPress={() => {
                    navigation.navigate('LastPage');
                  }}>
                 Next
                </Text>
              </TouchableOpacity>
             </View>
    </View>
  );
}
const styles = StyleSheet.create({
  input: {
    height: 40,
    width: 170,
    borderWidth: 1,
    padding: 10,
    borderColor: 'gray',
    marginLeft: 7,
    backgroundColor: 'white',
  },
  input2: {
    height: 40,
    width: 160,
    borderWidth: 1,
    padding: 10,
    marginTop: 10,
    borderColor: 'gray',
    backgroundColor: 'white',
  },
   btn: {
    borderRadius: 17,
    borderWidth: 1,
    border: 'none',
    alignSelf: 'center',
    width: 200,
    height: 40,
    backgroundColor: '#85C88A',
    borderColor: 'white',
    top:22,
    
  },
   button: {
    borderRadius: 17,
    borderWidth: 1,
    border: 'none',
    alignSelf: 'center',
    width: 200,
    height: 40,
    backgroundColor: '#85C88A',
    borderColor: 'white',
    top:35,
    
  },
   java: {
    flexDirection: 'row',
    marginTop: 50,
  }
  
});

export default Reservations;
