import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, Image, TouchableOpacity } from 'react-native';
import { firebase } from '../config/firebase';

import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
function hotelRooms({ navigation, route }) {
  const hotel = route.params;
  const img = require('../assets/Images/hotel.jpg');
  const img6 = require('../assets/Images/menu.png');
    
  useEffect(() => {
    console.log(route.params);
  });

  return (
    <View style={styles.body}>
      <View>
        <Image
          source={{ uri: hotel.image }}
          style={{
            width: 310,
            height: 305,
            justifyContent: 'center',
            marginTop: 2,
            borderWidth: 1,
            borderRadius: 40,
            border:'none',
          }}
        />
      </View>
    
      <Card style={{alignSelf:'center',height:'27%',width:'95%'}}>
      <Text style={styles.text}></Text>
      <Text style={{ fontWeight: 'bold',  marginTop: -20,marginLeft:10}}>
        {route.params.name}
      </Text>

      <View style={styles.container}>
        <Text style={styles.text2}>Discriptions</Text>
        
        <Text style={{fontWeight:'relative',marginLeft:10}}>{route.params.Discriptions }</Text>
        <View style={styles.boders}>
          <View style={styles.border}>
            <View style={styles.head}></View>
            <View style={styles.icon}>
            <View>
              {route.params.wifi ? (
               <View><Ionicons name="wifi" size={32} color="#85C88A" style={{alignSelf:'center',marginTop:20,}} /></View>
              ) : (
                <View> </View>
              )}
          </View>
           <View>
              {route.params.wifi ? (
               <View><Ionicons name="car" size={32} color="#85C88A" style={{alignSelf:'center',marginTop:20,paddingLeft:10}} /></View>
              ) : (
                <View> </View>
              )}
          </View>
            <View>
              {route.params.wifi ? (
               <View><Ionicons name="tv" size={32} color="#85C88A" style={{alignSelf:'center',marginTop:20,paddingLeft:10}} /></View>
              ) : (
                <View> </View>
              )}
          </View>
           </View>
              <View>
                <Text style={{marginTop:19,marginLeft:12}}>prices from 1200</Text>
               
              </View>
            </View>
        </View>

        <TouchableOpacity style={styles.paragraph}>
          <Text
            style={styles.Text4}
            onPress={() => {
              navigation.navigate('Bookings');
            }}>
            Book now
          </Text>
        </TouchableOpacity>
      </View>
      </Card>
    </View>
  );
}
const styles = StyleSheet.create({
  text: {
    alignSelf: 'center',
    paddingTop: 30,
    marginLeft: 60,
    
  },
  text2: {
    marginLeft:10,
    marginTop: 120,
  },
 
  body: {
    backgroundColor: 'F7F7F7',
    height: '200vh',
    width: '100%vh',
    alignSelf:'center',
  },
 
 

  paragraph: {
    marginTop: 48,
    fontSize: 15,
    marginLeft: 30,
    borderRadius: 40,
    borderWidth: 1,
    alignSelf: 'center',
   border:'none',
    width: 200,
    height: 38,
    backgroundColor: '#85C88A',
  },
  Text4: {
    marginLeft: 55,
    color: 'white',
    marginTop: 7,
  },
 
  container: {
    marginTop: -105,
  },
  icon:{
    flexDirection:'row',
    alignSelf:'center',
    marginTop:-12
  }
});

export default hotelRooms;
