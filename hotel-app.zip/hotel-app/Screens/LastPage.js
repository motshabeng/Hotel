import React, {useState} from 'react'
import {
  StyleSheet,
  View,Text,Image,TouchableOpacity
} from 'react-native';
import { firebase } from '../config/firebase';
import { Ionicons } from '@expo/vector-icons';
import getDirections from 'react-native-google-maps-directions'
function LastPage({ navigation }) {

  const handleGetDirections = () => {
    const data = {
       source: {
        latitude: -28.741943,
        longitude: 24.771944
      },
      destination: {
        latitude: -28.741943,
        longitude: 24.771944
      },
      params: [
        {
          key: "travelmode",
          value: "driving"        // may be "walking", "bicycling" or "transit" as well
        },
        {
          key: "dir_action",
          value: "navigate"       // this instantly initializes navigation using the given travel mode
        }
      ],
      waypoints: [
        {
          latitude: -33.8600025,
          longitude: 18.697452
        },
        {
          latitude: -33.8600026,
          longitude: 18.697453
        },
           {
          latitude: -33.8600036,
          longitude: 18.697493
        }
      ]
    }
    getDirections(data)
  }
   
            
return(
  <View style={styles.container}>
 <View><Ionicons name="md-checkmark-circle" size={32} color="green" style={{alignSelf:'center',marginTop:20}} /></View>
 <View>
<Text style={{marginTop:16,fontSize:27,alignSelf:'center'}}>Well come!</Text><Text style={{marginTop:25,alignSelf:'center',fontSize:17,color: '#85C88A'}}>enjoy your stay</Text>
  </View>
  <View>
  <TouchableOpacity
          style={styles.btn}
          onPress={handleGetDirections} title="Get Directions">
         <Text style={{alignSelf:'center',marginTop:10,fontSize:16,fontWeight:'bold',color:'white'}}> Directions</Text>
            </TouchableOpacity></View>
  </View>
)
}
const styles= StyleSheet.create({
 container:{
    justifyContent:'center',
    alignContent:'center',
    backgroundColor:"white",
    height:'100%' 
 },
   btn: {
    borderRadius: 17,
    borderWidth: 1,
    border: 'none',
    alignSelf: 'center',
    width: 200,
    height: 40,
    backgroundColor: '#85C88A',
    borderColor: 'white',
    top:22,
    
  },

  
  
})
export default LastPage;
