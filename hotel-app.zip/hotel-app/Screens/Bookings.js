import React, {useState} from 'react';
import { StyleSheet,
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
  Picker,
  TextInput,} from 'react-native'
import Calendar from 'react-calendar';
import moment from 'moment';
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import {firebase} from '../config/firebase';
import RNPickerSelect from "react-native-picker-select";
const App = ({navigation}) => {
  const [dateState, setDateState] = useState(new Date())
  const changeDate = (e) => {
    setDateState(e)
  }
  const [selectedValue, setSelectedValue] = useState('java');
 const [firstName, setFirstName] = useState("")
 const [lastName, setLastName] = useState("")
 const [email, setEmail] = useState("")
 const [address, setAddress] = useState("")
 const [city, setCity] = useState("")
const [checkIn, setCheckIn] = useState("")
const [checkOut, setCheckOut] = useState("")
const [children, setChildren] = useState("")
const [adult, setAdult] = useState("")


   
 const Navigation = () => {
  firebase.firestore().collection("Bookings").doc(firebase.auth().currentUser.uid).set({
    firstName,
    lastName,
    email,
    address,
    city,
    checkIn,
    checkOut,
    children,
    adult,


   
})
.then(() => {
    console.log("Document successfully written!");
})
.catch((error) => {
    console.error("Error writing document: ", error);
});
}
    

            

  return (
    <View style={styles.container}>
      <Text
        style={{
          alignSelf: 'center',
          fontSize: 20,
          fontWeight: 'bold',
          marginTop: -20,
          color:'gray'
        }}>
        Reservations Details
      </Text>

    <View>
   
     
    
              <View>
              
              <TouchableOpacity onPress={() => {navigation.navigate('HotelSearch')}}>
                <Ionicons name="menu" size={32} color= '#85C88A' style={{alignSelf:'center',marginTop:-30,marginRight:250}} />
               
              </TouchableOpacity>
             </View> 
           
              
           
  </View>
  <View
        style={{ flexDirection: 'row', marginTop: 20, alignSelf: 'center' }}>
        <View style={{ marginLeft: -10, padding: 10 }}>
          <TextInput style={styles.input} placeholder="First Name"   onChangeText= {(name) => setFirstName(name)} />
        </View>
        <View>
          <TextInput style={styles.input2} placeholder="Last Name"  onChangeText= {(name) => setLastName(name)}/>
        </View>
      </View>
      <View style={{ flexDirection: 'row', alignSelf: 'center' }}>
        <View style={{ marginLeft: -10, padding: 10 }}>
          <TextInput style={styles.input} placeholder="E-mail"  onChangeText= {(name) => setEmail(name)}/>
        </View>
        <View>
          <TextInput style={styles.input2} placeholder="Address"  onChangeText= {(name) => setAddress(name)}/>
        </View>
        
      </View>
        <View style={{ flexDirection: 'row', alignSelf: 'center' }}>
        <View style={{ marginLeft: -10, padding: 10 }}>
          <TextInput style={styles.input} placeholder="checkIn"  onChangeText= {(name) => setCheckIn(name)}/>
        </View>
        <View >
          <TextInput style={styles.input2} placeholder="check-out"  onChangeText= {(name) => setCheckOut(name)}/>
        </View>
        </View>
        
      <View
        style={{ flexDirection: 'row', marginTop: 40, alignSelf: 'center' }}>
        
        <View style={{ marginLeft: -10, padding: 10,marginTop:-30 }}>
          <TextInput style={styles.input} placeholder="City"  onChangeText= {(name) => setCity(name)}/>
          </View>
          <View style={{marginTop:-30}}>
            <TextInput style={styles.input2} placeholder="Phone number" />
        </View>
      </View>
        <View style={styles.java}>
    <Text style={{ marginLeft: 1, fontWeight: 'relative', justifyContent: 'space-evenly'}}>Adults</Text>
    <RNPickerSelect
                 onValueChange={(value) => console.log(value)}
                 items={[
                  { label: "1", value: "1" },
                  { label: "2", value: "2" },
                  { label: "3", value: "3" },
                  { label: "more", value: "more" },
                 ]}
             />
                 <Text style={{ marginLeft: 3, fontWeight: 'relative', justifyContent: 'space-evenly'}}>Childen</Text>
               <RNPickerSelect style={{width:5}}
                 onValueChange={(value) => console.log(value)}
                 items={[
                     { label: "1", value: "1" },
                     { label: "2", value: "2" },
                     { label: "3", value: "3" },
                     { label: "more", value: "more" },
                 ]}
             />
    </View>
  <View>
    <View style={styles.calender}>
      <Calendar
      value={dateState}
      onChange={changeDate}
      
      />
    </View>
    </View>
    <p>Current selected date is <b>{moment(dateState).format('MMMM Do YYYY')}</b></p>
    
   <View style={{flexDirection:'row'}}> 
         
             <View style={styles.btn}>
              <TouchableOpacity onPress={Navigation}>
                <Text style={{color:'white',alignSelf:'center',marginTop:10,fontWeight:'bold'}}>Submit</Text>
              </TouchableOpacity>

              </View>
            
              <View style={styles.button}>
              <TouchableOpacity >
                <Text
                  style={{color:'white',alignSelf:'center',marginTop:7,fontWeight:'bold'}}
                  onPress={() => {
                    navigation.navigate('LastPage');
                  }}>
                 Next
                </Text>
              </TouchableOpacity>
             </View>
              </View>
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 10,
    padding: 8,
    justifyContent: 'center',
    alignItems: 'center',
    height:'100%'
  },
 calender: {
    marginTop: 10,
    marginHorizontal: 20,
    alignSelf:'center',
    width:200
  },
  button: {
    borderRadius: 17,
    borderWidth: 1,
    border: 'none',
    alignSelf: 'center',
    width: 120,
    height: 40,
    backgroundColor: '#85C88A',
    borderColor: 'white',
    top:22,
    marginLeft:10
    
    
  },
 
 
  input: {
    height: 40,
    width: 170,
    borderWidth: 1,
    padding: 10,
    borderColor: 'gray',
    marginLeft: 7,
    backgroundColor: 'white',
  },
  input2: {
    height: 40,
    width: 160,
    borderWidth: 1,
    padding: 10,
    marginTop: 10,
    borderColor: 'gray',
    backgroundColor: 'white',
  },
   btn: {
    borderRadius: 17,
    borderWidth: 1,
    border: 'none',
    alignSelf: 'center',
    width: 120,
    height: 40,
    backgroundColor: '#85C88A',
    borderColor: 'white',
    top:22,
    
    
  },
 
   java: {
    flexDirection: 'row',
    marginTop: 7,
  },
  

 
});
export default App